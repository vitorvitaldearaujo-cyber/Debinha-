package com.vitor.agenda;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import org.json.JSONObject;

public class AlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent in) {
        String item = in.getStringExtra("item");
        if (item == null) return;
        try {
            Intent s = new Intent(c, AlarmService.class).putExtra("item", item);
            c.startForegroundService(s);
        } catch (Exception e) {
            // Sem permissão de serviço em primeiro plano: ao menos mostra a notificação.
            try { AlarmService.notificarSimples(c, new JSONObject(item)); } catch (Exception ignored) {}
        }
    }
}

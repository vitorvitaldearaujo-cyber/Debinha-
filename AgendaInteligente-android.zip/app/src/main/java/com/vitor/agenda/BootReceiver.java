package com.vitor.agenda;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import org.json.JSONArray;
import org.json.JSONObject;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent in) {
        Alarmes.reagendar(c);
        if (!Intent.ACTION_BOOT_COMPLETED.equals(in.getAction())) return;
        // Alarmes que passaram enquanto o aparelho estava desligado (últimos 30 min): avisa como perdidos.
        try {
            long agora = System.currentTimeMillis();
            JSONArray a = Alarmes.arr(c, "itens");
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                long t = o.optLong("t");
                if (t <= agora && t > agora - 30 * 60000L) {
                    JSONObject p = o.getJSONObject("p");
                    p.put("corpo", "Perdido (aparelho desligado) · " + p.optString("corpo", ""));
                    AlarmService.notificarSimples(c, o);
                }
            }
        } catch (Exception ignored) {}
    }
}

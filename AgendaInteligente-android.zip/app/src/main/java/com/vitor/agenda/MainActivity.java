package com.vitor.agenda;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.View;
import android.view.WindowManager;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.InputStream;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    static final String HOST = "appassets.androidplatform.net";
    private WebView web;
    private ValueCallback<Uri[]> chooser;
    private String alertaPendente = null;
    private boolean carregada = false;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        AlarmService.canal(this);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setGeolocationEnabled(true);
        web.addJavascriptInterface(new Bridge(this), "AndroidAlarm");
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (!HOST.equals(u.getHost())) return null;
                String p = u.getPath() == null ? "/" : u.getPath();
                if (p.equals("/") || p.length() == 0) p = "/index.html";
                try {
                    InputStream in = getAssets().open(p.substring(1));
                    String mime = p.endsWith(".html") ? "text/html" : p.endsWith(".js") ? "text/javascript"
                        : p.endsWith(".png") ? "image/png" : p.endsWith(".webmanifest") ? "application/manifest+json" : "application/octet-stream";
                    return new WebResourceResponse(mime, "utf-8", in);
                } catch (Exception e) { return null; }
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                if (HOST.equals(r.getUrl().getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, r.getUrl())); } catch (Exception ignored) {}
                return true;
            }
            @Override public void onPageFinished(WebView v, String url) { carregada = true; entregarAlerta(); }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (chooser != null) chooser.onReceiveValue(null);
                chooser = cb;
                try { startActivityForResult(p.createIntent(), 21); } catch (Exception e) { chooser = null; return false; }
                return true;
            }
            @Override public void onPermissionRequest(final PermissionRequest r) {
                runOnUiThread(new Runnable() { public void run() {
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 12);
                    r.grant(r.getResources());
                }});
            }
            @Override public void onGeolocationPermissionsShowPrompt(String o, GeolocationPermissions.Callback cb) {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 13);
                cb.invoke(o, true, false);
            }
        });
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 11);
        guardarAlerta(getIntent());
        web.loadUrl("https://" + HOST + "/index.html");
    }

    private void guardarAlerta(Intent i) {
        if (i != null && i.getStringExtra("alerta") != null && i.getStringExtra("alerta").length() > 2) alertaPendente = i.getStringExtra("alerta");
    }

    private void entregarAlerta() {
        if (!carregada || alertaPendente == null) return;
        String js = "window.__natAlerta&&window.__natAlerta(" + JSONObject.quote(alertaPendente) + ")";
        alertaPendente = null;
        web.evaluateJavascript(js, null);
    }

    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        guardarAlerta(i);
        entregarAlerta();
    }

    @Override protected void onResume() {
        super.onResume();
        if (carregada) { web.evaluateJavascript("window.__natResume&&window.__natResume()", null); entregarAlerta(); }
    }

    void escolherMusica() {
        runOnUiThread(new Runnable() { public void run() {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("audio/*")
                .putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(i, 22);
        }});
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == 21) {
            Uri[] r = null;
            if (res == RESULT_OK && data != null) r = WebChromeClient.FileChooserParams.parseResult(res, data);
            if (chooser != null) chooser.onReceiveValue(r);
            chooser = null;
        } else if (req == 22 && res == RESULT_OK && data != null) {
            JSONArray out = new JSONArray();
            try {
                if (data.getClipData() != null) for (int i = 0; i < data.getClipData().getItemCount(); i++) add(out, data.getClipData().getItemAt(i).getUri());
                else if (data.getData() != null) add(out, data.getData());
            } catch (Exception ignored) {}
            if (out.length() > 0) web.evaluateJavascript("window.__musicaNativa(" + JSONObject.quote(out.toString()) + ")", null);
        }
    }

    private void add(JSONArray out, Uri u) throws Exception {
        try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
        String nome = "Música";
        Cursor c = getContentResolver().query(u, null, null, null, null);
        if (c != null) { try { if (c.moveToFirst()) { int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (i >= 0) nome = c.getString(i); } } finally { c.close(); } }
        nome = nome.replaceFirst("\\.[A-Za-z0-9]+$", "");
        out.put(new JSONObject().put("uri", u.toString()).put("nome", nome));
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}

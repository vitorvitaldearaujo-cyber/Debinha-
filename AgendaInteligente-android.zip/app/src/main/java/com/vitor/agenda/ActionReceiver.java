package com.vitor.agenda;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import org.json.JSONObject;

/** Botões Concluído / Adiar / Parar da notificação — funcionam com o app fechado. */
public class ActionReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent in) {
        String acao = in.getStringExtra("acao"), item = in.getStringExtra("item");
        if (acao == null || item == null) return;
        try {
            JSONObject o = new JSONObject(item), p = o.getJSONObject("p");
            String key = p.optString("key", "");
            c.stopService(new Intent(c, AlarmService.class));
            ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(AlarmService.idDe(key));
            Alarmes.limparExtras(c, key);
            Alarmes.guardarAcao(c, acao, p);
            if ("adiar".equals(acao)) {
                JSONObject n = new JSONObject(item);
                JSONObject np = n.getJSONObject("p");
                np.put("key", Alarmes.base(key) + "~a" + System.currentTimeMillis());
                np.put("rep", 0);
                np.put("corpo", "⏳ Adiado · " + p.optString("corpo", "").replaceFirst("^(⏳|🔁)[^·]*·\\s*", ""));
                n.put("t", System.currentTimeMillis() + 10 * 60000L);
                Alarmes.addExtra(c, n);
            }
        } catch (Exception ignored) {}
    }
}

# Agenda Inteligente — app Android (alarmes com o app FECHADO)

Uma página HTML não consegue tocar alarme com o app fechado (o Android congela o navegador).
Este projeto empacota a agenda como APK e entrega os alarmes ao **AlarmManager** do Android:
toca a música escolhida, vibra e abre sobre a tela bloqueada, mesmo com o app fechado e
depois de reiniciar o celular.

## Como gerar o APK (escolha um)

**A) Sem instalar nada (GitHub Actions)**
1. Crie um repositório no GitHub e envie o conteúdo desta pasta (inclusive `.github`).
2. Aba **Actions → Gerar APK → Run workflow**. Em ~5 min baixe `AgendaInteligente-apk` (contém `app-debug.apk`).
3. Copie o APK para o celular e instale (permita "instalar apps desconhecidos").

**B) Android Studio**: *File → Open* nesta pasta → *Build → Build APK(s)*.

## Primeiro uso (essencial)
Em **Ajustes › Alarmes e notificações › Alarmes do sistema** libere os 4 itens:
Notificações, Alarmes exatos, Abrir sobre a tela bloqueada e Sem restrição de bateria.
Em Xiaomi/Samsung/Motorola/Oppo, ative também "Início automático" e bateria "Sem restrições" para o app.
Use **Testar alarme** e depois confira com o app fechado.

## Música do celular
Ajustes › Alarmes › **Escolher música do celular** (várias de uma vez). Depois escolha a música em
"Som por tipo" (despertador, consulta, lembrete…). O arquivo continua no celular; se for apagado, toca o alarme padrão.

## Observações
- Botões **Concluído / Adiar 10 min / Parar** funcionam direto na notificação.
- Sem resposta em 3 min, o despertador repete conforme Ajustes (vezes e intervalo).
- O app reagenda os próximos 30 dias sempre que você altera algo e ao abrir o app; abra-o ao menos 1 vez por mês.
- O código não foi compilado nem testado em um aparelho real neste ambiente (sem Android SDK).

package com.vitor.agenda;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;
import org.json.JSONObject;

/** Toca o alarme (música escolhida ou som interno), vibra e mantém a notificação — com o app fechado. */
public class AlarmService extends Service {
    static final String CANAL = "agenda_alarme_v1";
    static final long LIMITE_ALARME = 3 * 60000L, LIMITE_AVISO = 20000L;

    private MediaPlayer mp;
    private PowerManager.WakeLock wl;
    private AudioFocusRequest foco;
    private final Handler h = new Handler(Looper.getMainLooper());
    private Runnable fim;
    private JSONObject item, cfg;

    static int idDe(String key) { return 100 + ((key == null ? 0 : key.hashCode()) & 0x7ffff); }

    static void canal(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm.getNotificationChannel(CANAL) != null) return;
        NotificationChannel ch = new NotificationChannel(CANAL, "Alarmes e lembretes", NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("Alarmes, lembretes, tarefas e aniversários");
        ch.setSound(null, null);       // o som é tocado pelo serviço (música escolhida)
        ch.enableVibration(false);     // a vibração também
        ch.setBypassDnd(true);
        ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(ch);
    }

    static PendingIntent abrir(Context c, JSONObject it, int req) {
        Intent i = new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP)
            .putExtra("alerta", it.optJSONObject("p") == null ? "" : it.optJSONObject("p").toString());
        return PendingIntent.getActivity(c, req, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    static PendingIntent acao(Context c, String a, JSONObject it, int id) {
        Intent i = new Intent(c, ActionReceiver.class).setAction("com.vitor.agenda." + a + id)
            .putExtra("acao", a).putExtra("item", it.toString());
        return PendingIntent.getBroadcast(c, id * 3 + ("feito".equals(a) ? 0 : "adiar".equals(a) ? 1 : 2), i,
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    static Notification montar(Context c, JSONObject it, JSONObject cfg, boolean tocando) {
        canal(c);
        JSONObject p = it.optJSONObject("p");
        if (p == null) p = new JSONObject();
        boolean oculto = cfg.optBoolean("ocultar", false);
        String titulo = oculto ? "Agenda: lembrete" : (p.optString("ic", "") + " " + p.optString("titulo", "Lembrete")).trim();
        String corpo = oculto ? "Toque para ver" : p.optString("corpo", "");
        int id = idDe(p.optString("key", ""));
        boolean info = "pe".equals(p.optString("src")) || p.optInt("min", 0) > 0;
        Notification.Builder b = new Notification.Builder(c, CANAL)
            .setSmallIcon(R.drawable.ic_stat).setContentTitle(titulo).setContentText(corpo)
            .setStyle(new Notification.BigTextStyle().bigText(corpo))
            .setCategory(Notification.CATEGORY_ALARM).setVisibility(Notification.VISIBILITY_PUBLIC)
            .setContentIntent(abrir(c, it, id))
            .setOngoing(tocando).setAutoCancel(!tocando).setWhen(it.optLong("t", System.currentTimeMillis())).setShowWhen(true);
        if (tocando) b.setFullScreenIntent(abrir(c, it, id + 1), true);
        if (!info) b.addAction(new Notification.Action.Builder(null, "✓ Concluído", acao(c, "feito", it, id)).build());
        if (!info) b.addAction(new Notification.Action.Builder(null, "⏳ Adiar 10 min", acao(c, "adiar", it, id)).build());
        else b.addAction(new Notification.Action.Builder(null, "👍 Entendido", acao(c, "ok", it, id)).build());
        if (tocando && !info) b.addAction(new Notification.Action.Builder(null, "■ Parar", acao(c, "ok", it, id)).build());
        return b.build();
    }

    static void notificarSimples(Context c, JSONObject it) {
        try {
            Notification n = montar(c, it, Alarmes.cfg(c), false);
            ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(idDe(it.getJSONObject("p").optString("key", "")), n);
        } catch (Exception ignored) {}
    }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent in, int flags, int startId) {
        String s = in == null ? null : in.getStringExtra("item");
        if (s == null) { stopSelf(); return START_NOT_STICKY; }
        try {
            parar();
            item = new JSONObject(s);
            cfg = Alarmes.cfg(this);
            JSONObject p = item.getJSONObject("p");
            boolean ring = p.optBoolean("ring", false);
            Notification n = montar(this, item, cfg, true);
            int id = idDe(p.optString("key", ""));
            if (Build.VERSION.SDK_INT >= 29) startForeground(id, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            else startForeground(id, n);
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "agenda:alarme");
            wl.acquire(LIMITE_ALARME + 5000);
            tocar(item.optString("som", "alarme"), item.optString("uri", ""), ring, cfg.optDouble("vol", 0.85));
            if (cfg.optBoolean("vibrar", true)) vibrar(ring);
            fim = new Runnable() { public void run() { terminar(); } };
            h.postDelayed(fim, ring ? LIMITE_ALARME : LIMITE_AVISO);
        } catch (Exception e) {
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private void tocar(String som, String uri, boolean loop, double vol) {
        if ("mudo".equals(som)) return;
        AudioAttributes aa = new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build();
        try {
            AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
            foco = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE).setAudioAttributes(aa).build();
            am.requestAudioFocus(foco);
        } catch (Exception ignored) {}
        boolean ok = false;
        if ("musica".equals(som) && uri != null && uri.length() > 0) ok = abrir(aa, Uri.parse(uri), loop, vol);
        else {
            int r = getResources().getIdentifier(som, "raw", getPackageName());
            if (r != 0) ok = abrirRaw(aa, r, loop, vol);
        }
        if (!ok) ok = abrir(aa, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), loop, vol);
    }

    private boolean abrir(AudioAttributes aa, Uri u, boolean loop, double vol) {
        try {
            MediaPlayer m = new MediaPlayer();
            m.setAudioAttributes(aa);
            m.setDataSource(this, u);
            return iniciar(m, loop, vol);
        } catch (Exception e) { return false; }
    }

    private boolean abrirRaw(AudioAttributes aa, int res, boolean loop, double vol) {
        try {
            MediaPlayer m = new MediaPlayer();
            m.setAudioAttributes(aa);
            android.content.res.AssetFileDescriptor fd = getResources().openRawResourceFd(res);
            m.setDataSource(fd.getFileDescriptor(), fd.getStartOffset(), fd.getLength());
            fd.close();
            return iniciar(m, loop, vol);
        } catch (Exception e) { return false; }
    }

    private boolean iniciar(MediaPlayer m, boolean loop, double vol) {
        try {
            m.setLooping(loop);
            float v = (float) Math.max(0.05, Math.min(1.0, vol));
            m.setVolume(v, v);
            m.prepare();
            m.start();
            mp = m;
            return true;
        } catch (Exception e) { try { m.release(); } catch (Exception ignored) {} return false; }
    }

    private void vibrar(boolean ring) {
        try {
            Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            long[] pad = {0, 500, 250, 500, 250, 800, 900};
            v.vibrate(VibrationEffect.createWaveform(pad, ring ? 0 : -1));
        } catch (Exception ignored) {}
    }

    /** Fim do tempo sem resposta: para o som, mantém a notificação e agenda repetição (despertador). */
    private void terminar() {
        try {
            JSONObject p = item.getJSONObject("p");
            boolean ring = p.optBoolean("ring", false);
            int rep = p.optInt("rep", 0), max = cfg.optInt("repVezes", 0);
            if (ring && "x".equals(p.optString("src")) == false && rep < max) {
                JSONObject n = new JSONObject(item.toString());
                JSONObject np = n.getJSONObject("p");
                np.put("rep", rep + 1);
                np.put("key", Alarmes.base(p.optString("key", "")) + "~r" + (rep + 1));
                np.put("corpo", "🔁 Repetindo (" + (rep + 1) + "/" + max + ") · " + p.optString("corpo", "").replaceFirst("^🔁[^·]*·\\s*", ""));
                n.put("t", System.currentTimeMillis() + cfg.optLong("repMin", 5) * 60000L);
                Alarmes.addExtra(this, n);
            }
            parar();
            stopForeground(STOP_FOREGROUND_DETACH);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(idDe(p.optString("key", "")), montar(this, item, cfg, false));
        } catch (Exception ignored) {}
        stopSelf();
    }

    private void parar() {
        h.removeCallbacksAndMessages(null);
        try { if (mp != null) { mp.stop(); mp.release(); } } catch (Exception ignored) {}
        mp = null;
        try { ((Vibrator) getSystemService(VIBRATOR_SERVICE)).cancel(); } catch (Exception ignored) {}
        try { if (foco != null) ((AudioManager) getSystemService(AUDIO_SERVICE)).abandonAudioFocusRequest(foco); } catch (Exception ignored) {}
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Exception ignored) {}
    }

    @Override public void onDestroy() { parar(); super.onDestroy(); }
}

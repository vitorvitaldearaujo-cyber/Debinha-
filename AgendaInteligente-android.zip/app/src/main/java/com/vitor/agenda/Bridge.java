package com.vitor.agenda;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import java.io.OutputStream;
import org.json.JSONObject;

/** Ponte JS ↔ Android: window.AndroidAlarm.* */
public class Bridge {
    private final MainActivity a;
    private MediaPlayer prev;

    Bridge(MainActivity a) { this.a = a; }

    @JavascriptInterface public void agendar(String json) {
        try { Alarmes.salvar(a, json); } catch (Exception ignored) {}
    }

    @JavascriptInterface public void tocarAgora(String json) {
        try {
            JSONObject o = new JSONObject(json);
            Alarmes.sp(a).edit().putString("cfg", o.getJSONObject("cfg").toString()).apply();
            a.startForegroundService(new Intent(a, AlarmService.class).putExtra("item", o.getJSONObject("item").toString()));
        } catch (Exception ignored) {}
    }

    @JavascriptInterface public void parar(String key) {
        try {
            a.stopService(new Intent(a, AlarmService.class));
            if (key != null && key.length() > 0) {
                ((NotificationManager) a.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(AlarmService.idDe(key));
                Alarmes.limparExtras(a, key);
            }
        } catch (Exception ignored) {}
    }

    @JavascriptInterface public String pegarAcoes() { return Alarmes.pegarAcoes(a); }

    @JavascriptInterface public void preview(String uri, boolean loop, double vol) {
        pararPreview();
        try {
            MediaPlayer m = new MediaPlayer();
            m.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            m.setDataSource(a, Uri.parse(uri));
            m.setLooping(loop);
            float v = (float) Math.max(0.05, Math.min(1.0, vol));
            m.setVolume(v, v);
            m.prepare();
            m.start();
            prev = m;
        } catch (Exception e) { prev = null; }
    }

    @JavascriptInterface public void pararPreview() {
        try { if (prev != null) { prev.stop(); prev.release(); } } catch (Exception ignored) {}
        prev = null;
    }

    @JavascriptInterface public String status() {
        try {
            NotificationManager nm = (NotificationManager) a.getSystemService(Context.NOTIFICATION_SERVICE);
            AlarmManager am = (AlarmManager) a.getSystemService(Context.ALARM_SERVICE);
            PowerManager pm = (PowerManager) a.getSystemService(Context.POWER_SERVICE);
            JSONObject o = new JSONObject();
            o.put("notif", nm.areNotificationsEnabled());
            o.put("exato", Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms());
            o.put("tela", Build.VERSION.SDK_INT < 34 || nm.canUseFullScreenIntent());
            o.put("bateria", pm.isIgnoringBatteryOptimizations(a.getPackageName()));
            o.put("agendados", Alarmes.sp(a).getInt("n", 0));
            return o.toString();
        } catch (Exception e) { return "{}"; }
    }

    @JavascriptInterface public void abrirConfig(final String k) {
        a.runOnUiThread(new Runnable() { public void run() {
            try {
                Uri pkg = Uri.parse("package:" + a.getPackageName());
                Intent i;
                if ("notif".equals(k)) {
                    if (Build.VERSION.SDK_INT >= 33 && a.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                        a.requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 11);
                        return;
                    }
                    i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, a.getPackageName());
                } else if ("exato".equals(k) && Build.VERSION.SDK_INT >= 31) i = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, pkg);
                else if ("tela".equals(k) && Build.VERSION.SDK_INT >= 34) i = new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, pkg);
                else if ("bateria".equals(k)) i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkg);
                else i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg);
                a.startActivity(i);
            } catch (Exception e) {
                try { a.startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + a.getPackageName()))); } catch (Exception ignored) {}
            }
        }});
    }

    @JavascriptInterface public void escolherMusica() { a.escolherMusica(); }

    @JavascriptInterface public void salvarArquivo(String nome, String b64, String mime) {
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Downloads.DISPLAY_NAME, nome);
            v.put(MediaStore.Downloads.MIME_TYPE, mime);
            v.put(MediaStore.Downloads.RELATIVE_PATH, "Download");
            Uri u = a.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            OutputStream os = a.getContentResolver().openOutputStream(u);
            os.write(Base64.decode(b64, Base64.DEFAULT));
            os.close();
        } catch (Exception ignored) {}
    }
}

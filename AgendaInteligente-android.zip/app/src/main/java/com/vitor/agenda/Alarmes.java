package com.vitor.agenda;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

/** Guarda a agenda de alarmes recebida do app (HTML) e a entrega ao AlarmManager do Android. */
final class Alarmes {
    private Alarmes() {}
    static final int MAX = 400;

    static SharedPreferences sp(Context c) { return c.getSharedPreferences("agenda_nat", Context.MODE_PRIVATE); }

    static JSONObject cfg(Context c) {
        try { return new JSONObject(sp(c).getString("cfg", "{}")); } catch (Exception e) { return new JSONObject(); }
    }

    static JSONArray arr(Context c, String k) {
        try { return new JSONArray(sp(c).getString(k, "[]")); } catch (Exception e) { return new JSONArray(); }
    }

    /** Recebe do JS: {cfg:{...}, itens:[{t,p,som,uri}]} */
    static void salvar(Context c, String json) throws Exception {
        JSONObject o = new JSONObject(json);
        sp(c).edit().putString("cfg", o.getJSONObject("cfg").toString())
            .putString("itens", o.getJSONArray("itens").toString()).apply();
        reagendar(c);
    }

    static String base(String key) { int i = key.indexOf('~'); return i < 0 ? key : key.substring(0, i); }

    static void addExtra(Context c, JSONObject item) throws Exception {
        JSONArray e = arr(c, "extras");
        e.put(item);
        sp(c).edit().putString("extras", e.toString()).apply();
        reagendar(c);
    }

    /** Remove repetições/adiamentos nativos de um alarme (quando o usuário responde). */
    static void limparExtras(Context c, String key) {
        try {
            String b = base(key);
            JSONArray e = arr(c, "extras"), n = new JSONArray();
            for (int i = 0; i < e.length(); i++) {
                String k = e.getJSONObject(i).getJSONObject("p").optString("key", "");
                if (!base(k).equals(b)) n.put(e.getJSONObject(i));
            }
            sp(c).edit().putString("extras", n.toString()).apply();
            reagendar(c);
        } catch (Exception ignored) {}
    }

    static PendingIntent pi(Context c, int i, String item, boolean criar) {
        Intent it = new Intent(c, AlarmReceiver.class).setAction("com.vitor.agenda.ALARME");
        if (item != null) it.putExtra("item", item);
        int fl = PendingIntent.FLAG_IMMUTABLE | (criar ? PendingIntent.FLAG_UPDATE_CURRENT : PendingIntent.FLAG_NO_CREATE);
        return PendingIntent.getBroadcast(c, i, it, fl);
    }

    static void reagendar(Context c) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            SharedPreferences s = sp(c);
            int antes = s.getInt("n", 0);
            for (int i = 0; i < antes; i++) {
                PendingIntent p = pi(c, i, null, false);
                if (p != null) { am.cancel(p); p.cancel(); }
            }
            long agora = System.currentTimeMillis();
            List<JSONObject> l = new ArrayList<>();
            for (String k : new String[]{"itens", "extras"}) {
                JSONArray a = arr(c, k);
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.getJSONObject(i);
                    if (o.optLong("t") > agora) l.add(o);
                }
            }
            Collections.sort(l, new Comparator<JSONObject>() {
                public int compare(JSONObject a, JSONObject b) { return Long.compare(a.optLong("t"), b.optLong("t")); }
            });
            if (l.size() > MAX) l = l.subList(0, MAX);
            boolean exato = android.os.Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms();
            Intent abrir = new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            PendingIntent show = PendingIntent.getActivity(c, 9999, abrir, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            for (int i = 0; i < l.size(); i++) {
                JSONObject o = l.get(i);
                PendingIntent p = pi(c, i, o.toString(), true);
                long t = o.optLong("t");
                if (exato) am.setAlarmClock(new AlarmManager.AlarmClockInfo(t, show), p);
                else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, p);
            }
            s.edit().putInt("n", l.size()).apply();
        } catch (Exception ignored) {}
    }

    // ----- ações pendentes (botões da notificação) para o JS ler quando o app abrir
    static void guardarAcao(Context c, String acao, JSONObject p) {
        try {
            JSONArray a = arr(c, "acoes");
            JSONObject o = new JSONObject();
            o.put("acao", acao); o.put("p", p); o.put("t", System.currentTimeMillis());
            a.put(o);
            sp(c).edit().putString("acoes", a.toString()).apply();
        } catch (Exception ignored) {}
    }

    static String pegarAcoes(Context c) {
        String r = sp(c).getString("acoes", "[]");
        sp(c).edit().putString("acoes", "[]").apply();
        return r;
    }
}
